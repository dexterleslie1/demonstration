package com.future.captcha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Dexterleslie.Chan
 */
@SpringBootApplication
//@ComponentScan(basePackages = "com.future.study")
public class ApplicationCaptcha {
    /**
     *
     * @param args
     */
    public static void main(String []args){
        SpringApplication.run(ApplicationCaptcha.class, args);
    }
}
