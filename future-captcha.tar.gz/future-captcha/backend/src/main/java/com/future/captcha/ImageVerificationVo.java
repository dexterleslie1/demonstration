package com.future.captcha;


import lombok.Data;

import java.io.Serializable;

@Data
public class ImageVerificationVo implements Serializable {
//    private String originImage;     //滑动验证码:源图
    private String shadeImage;      //滑动验证码:遮罩图
    private String cutoutImage;     //滑动验证码:裁剪图
    private int x;                  //滑动验证码:X轴
    private int y;                  //滑动验证码:Y轴
    private String uuId;            //唯一请求ID，用于保存redis
}