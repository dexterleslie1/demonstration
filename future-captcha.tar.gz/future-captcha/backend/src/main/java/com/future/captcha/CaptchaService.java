package com.future.captcha;

import com.yyd.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class CaptchaService {

    @Autowired
    RedisTemplate redisTemplate;

    private long captchaRedisTimeOut = 300;

    @Value("${com.xy.chat.config.common.production:false}")
    private boolean isProduction;

    final static String TMP_DIR = "/tmp";

    public ImageVerificationVo selectSlideVerificationCode() throws Exception {
        return getSlideVerificationCode();
    }

    //相对路径,使用Springboot集成方法
    //jar中的文件访问不能使用resource.getFile, 而必须使用getInputStream.
    private ImageVerificationVo getSlideVerificationCode() throws Exception {
        ImageVerificationVo imageVerificationVo = null;
        InputStream inputStream = null;
        File templateImageFile = null;
        File borderImageFile = null;
        File originImageFile = null;
        try {
            File dir = new File(TMP_DIR);
            if (!dir.exists()) dir.mkdirs();
            String tmpFilePrefix = TMP_DIR + "/byteToFile#" + UUID.randomUUID();
            ClassPathResource cpr = new ClassPathResource("/static/templates/template.png");
            String outFileName = tmpFilePrefix + "template.png";
            inputStream = cpr.getInputStream();
            templateImageFile = JavaIO.inputStreamToFile(inputStream, outFileName);


            cpr = new ClassPathResource("/static/templates/border.png");
            outFileName = tmpFilePrefix + "border.png";
            inputStream = cpr.getInputStream();
            borderImageFile = JavaIO.inputStreamToFile(inputStream, outFileName);

            //  随机取得原图文件夹中一张图片
            ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            Resource[] resources = resolver.getResources("classpath:static/targets/*.jpg");
            int rnd = new Random().nextInt(resources.length);
            outFileName = tmpFilePrefix + "background.jpg";
            inputStream = resources[rnd].getInputStream();
            originImageFile = JavaIO.inputStreamToFile(inputStream, outFileName);

            imageVerificationVo =
                    getSlideVerificationCode(originImageFile, templateImageFile, borderImageFile);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) inputStream.close();
            //删除临时文件!
            forceDelete(originImageFile);
            forceDelete(templateImageFile);
            forceDelete(borderImageFile);
        }
        return imageVerificationVo;
    }

    /**
     * 强制删除
     * @param file
     * @return
     */
    public static boolean forceDelete(File file) {
        boolean result = false;
        int tryCount = 0;
        while (!result && tryCount++ < 5) {
            System.gc();
            result = file.delete();
            if(tryCount>2) {
//                log.trace("try.to.Delete:("+tryCount+"/5)" + file.toString());
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
//        if (!result) log.trace("Delete.File.failed!->" + file.toString());
        return result;
    }

    private ImageVerificationVo getSlideVerificationCode(File originImageFile, File templateImageFile, File borderImageFile)
            throws Exception {
        //  获取描边图片类型
        String borderImageFileType = borderImageFile.getName().substring(borderImageFile.getName().lastIndexOf(".") + 1);
        //  获取原图文件类型
        String originImageFileType = originImageFile.getName().substring(originImageFile.getName().lastIndexOf(".") + 1);
        //  获取模板图文件类型
        String templateImageFileType = templateImageFile.getName().substring(templateImageFile.getName().lastIndexOf(".") + 1);
        //  读取原图
        BufferedImage verificationImage = ImageIO.read(originImageFile);
        //  读取模板图
        BufferedImage readTemplateImage = ImageIO.read(templateImageFile);
        //  读取描边图片
        BufferedImage borderImage = ImageIO.read(borderImageFile);

        //  获取原图感兴趣区域坐标
        ImageVerificationVo imageVerificationVo = ImageVerificationUtil.generateCutoutCoordinates(verificationImage, readTemplateImage);
        //测试环境x,y固定为:5
        /*if(!isProduction){
            imageVerificationVo.setX(5);
            imageVerificationVo.setY(5);
        }*/
        int y = imageVerificationVo.getY();

        String uuId = UUID.randomUUID().toString();
        String value = imageVerificationVo.getX() + "," + y;
        ValueOperations<String, String> operations = redisTemplate.opsForValue();
        operations.set(uuId, value, captchaRedisTimeOut, TimeUnit.SECONDS);

        //  根据原图生成遮罩图和切块图
        imageVerificationVo = ImageVerificationUtil.pictureTemplateCutout(originImageFile, originImageFileType, templateImageFile, templateImageFileType, imageVerificationVo.getX(), imageVerificationVo.getY());

        //   剪切图描边
        ImageVerificationUtil.cutoutImageEdge(imageVerificationVo, borderImage, borderImageFileType);
        imageVerificationVo.setY(y);

        //用于兼容IE6、7、8访问mhtml数据! 页面加载时调用!
        operations.set("mhtml#" + uuId, GetMhtml(imageVerificationVo), 30, TimeUnit.SECONDS);
        imageVerificationVo.setUuId(uuId);
        return imageVerificationVo;
    }

    //用于兼容IE6、7、8访问mhtml数据!
    public String getMhtmlBase64(String uuId) {
        ValueOperations<String, String> operations = redisTemplate.opsForValue();
        String mhtml = operations.get("mhtml#" + uuId);
        return mhtml;
    }

    /**
     * 滑动验证码验证方法
     *
     * @param uuId
     * @param x    x轴坐标
     * @param y    y轴坐标
     * @return 滑动验证码验证状态
     */
    public boolean checkVerificationResult(String uuId, String x, String y,int type) throws BusinessException {

        if (!redisTemplate.hasKey(uuId)) {
            throw new BusinessException("拼图验证超时失效，刷新完成拼图再继续！");
        }
        if (x.indexOf(".") > 0) {
            x = new BigDecimal(x).toBigInteger() + "";
        }
        if (y.indexOf(".") > 0) {
            y = new BigDecimal(y).toBigInteger() + "";
        }

        //从redis取出X,Y数据
        ValueOperations<String, String> operations = redisTemplate.opsForValue();
        String[] values = operations.get(uuId).split(",");
        int redis_x = Integer.parseInt(values[0]);
        int redis_y = Integer.parseInt(values[1]);

        int threshold = 5;  //设置容差
//        System.err.println("x,y,threshold=" + x + "," + y + "," + threshold);
//        System.err.println("redis_x,redis_y=" + redis_x + "," + redis_y);

        if ((Math.abs(Integer.parseInt(x) - redis_x) <= threshold)
                && (Math.abs(Integer.parseInt(y) - redis_y) <= threshold)) {
//            System.err.println("验证成功");
            //第一次提交验证成功，重置保存时间，与前端重刷时间一样
            if(type>0&&redisTemplate.hasKey(uuId))
                redisTemplate.expire(uuId, captchaRedisTimeOut, TimeUnit.SECONDS);
            return true;
        } else {
            //前端需要重刷新背景图与获取新X，此处删除redis.uuid
            if(redisTemplate.hasKey(uuId)) redisTemplate.delete(uuId);
//            System.err.println("验证失败");
            return false;
        }
    }


    public String GetMhtml(ImageVerificationVo imageVerificationVo) {
        return "<!--\n" +
                "Content-Type: multipart/related; boundary=\"imagedata\"\n" +
                "\n" +
                "--imagedata\n" +
                "Content-Type: image/jpeg\n" +
                "Content-Location: shade\n" +
                "Content-Transfer-Encoding: base64\n" +
                "\n" +
                imageVerificationVo.getShadeImage() +
                "\n" +
                "--imagedata\n" +
                "Content-Type: image/png\n" +
                "Content-Location: cutout\n" +
                "Content-Transfer-Encoding: base64\n" +
                "\n" +
                imageVerificationVo.getCutoutImage() +
                "\n" +
                "-->";
    }

}
