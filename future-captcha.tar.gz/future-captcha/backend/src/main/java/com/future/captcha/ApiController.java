package com.future.captcha;

import com.pig4cloud.captcha.ArithmeticCaptcha;
import com.yyd.common.http.ResponseUtils;
import com.yyd.common.http.response.ObjectResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping(value = "/api/v1/captcha")
// todo 搞清楚是否有安全隐患
@CrossOrigin
@Slf4j
public class ApiController {

    @Resource
    CaptchaService captchaService;

    final static Integer DEFAULT_IMAGE_WIDTH = 100;
    final static Integer DEFAULT_IMAGE_HEIGHT = 40;

    @GetMapping(value = "get")
    public ObjectResponse<String> get(@RequestParam(value = "identifier", defaultValue = "") String identifier) {
        ArithmeticCaptcha captcha = new ArithmeticCaptcha(DEFAULT_IMAGE_WIDTH, DEFAULT_IMAGE_HEIGHT);
        String base64 = captcha.toBase64();
        return ResponseUtils.successObject(base64);
    }

    @GetMapping(value = "getSliding")
    public ObjectResponse<ImageVerificationVo> get() throws Exception {
        ImageVerificationVo imageVerificationVo = captchaService.selectSlideVerificationCode();
        imageVerificationVo.setCutoutImage("data:image/png;base64," + imageVerificationVo.getCutoutImage());
        imageVerificationVo.setShadeImage("data:image/png;base64," + imageVerificationVo.getShadeImage());
        return ResponseUtils.successObject(imageVerificationVo);
    }
}
