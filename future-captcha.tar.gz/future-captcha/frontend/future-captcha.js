// todo 发布版自动把captcha.html中模板替换到这个变量中
var htmlTemplate = ``

$(document).ready(function () {
    // 重新加载验证码
    var funReloadCaptcha = function () {

        // 显示算术验证码面板
        $("#future-captcha-art").show()

        $.ajax({
            type: "GET",
            url: "http://localhost:8080/api/v1/captcha/get",
            success: function (data) {
                $("#future-captcha-img").attr("src", data.data)
            },
            error(xhr, status, error) {
                console.log(xhr)
            }
        })
    }

    // 绑定验证码相关dom事件
    // 动态元素使用动态方法绑定事件
    // https://stackoverflow.com/questions/1525664/jquery-how-to-bind-onclick-event-to-dynamically-added-html-element
    $(document).on("click", "#future-captcha-img", function () {
        funReloadCaptcha()
    })
    $(document).on("click", "#future-captcha-change-captcha", function () {
        funReloadCaptcha()
    })

    // 点击滑动验证码按钮
    $("#btn1").bind("click", function () {
        $('#myModal').modal({ backdrop: 'static', keyboard: false });

        $.ajax({
            type: "GET",
            url: "http://localhost:8080/api/v1/captcha/get1",
            success: function (data) {
                $("#imgBig").attr("src", data.data.shadeImage)
                $("#imgToDrag").attr("src", data.data.cutoutImage)
            },
            error(xhr, status, error) {
                console.log(xhr)
            }
        })
    })

    // 加载验证码模板并添加到dom中
    var fnInitLoad = function () {
        funReloadCaptcha()

        $("#btn1").trigger("click")
        $("#divDrag").draggable({
            axis: "x", containment: "#divDragContainer", scroll: false,
            drag: function (event, ui) {
                var x = ui.position.left
                if (x < 5) {
                    x = 5
                }
                if (x > 265) {
                    x = 265
                }
                $("#imgToDrag").css({ left: x })
            }
        })
    }
    if (htmlTemplate == "") {
        $("#captchaPanel").load("captcha.html", function () {
            fnInitLoad()
        })
    } else {
        $("#captchaPanel").append(htmlTemplate)
        fnInitLoad()
    }
})